return {
  "natecraddock/workspaces.nvim", -- Plugin name (replace with the actual name)

  dependencies = {
    "nvim-telescope/telescope.nvim", -- Assuming you need Telescope as a dependency
  },

  config = function()
    require("workspaces").setup({
      hooks = {
        open = { "Telescope find_files" },
      },
    })
  end,
}
