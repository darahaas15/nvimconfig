return {
  "theprimeagen/vim-be-good",

  dependencies = {
    "nvim-lua/plenary.nvim",
  },

  config = function() end,
}
