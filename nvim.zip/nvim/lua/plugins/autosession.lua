return {
  "rmagatti/auto-session",

  dependencies = {
    "nvim-telescope/telescope.nvim", -- Only needed if you want to use session lens
  },

  lazy = false,

  config = function()
    require("auto-session").setup({
      auto_session_suppress_dirs = { "~/", "~/Projects", "~/Downloads", "/" },
    })
  end,
}
