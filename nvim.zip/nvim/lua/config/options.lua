-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options hereby
vim.g.lazygit_config = true
vim.g.lazyvim_python_lsp = "basedpyright"

-- Set the background color to match the terminal's background for all relevant UI elements
local hl_groups_transparent = {
  "Normal",
  "NormalNC",
  "SignColumn",
  "StatusLine",
  "StatusLineNC",
  "WinBar",
  "WinBarNC",
  "NeoTreeNormal",
  "NeoTreeNormalNC",
  "TelescopeNormal",
  "TelescopeBorder",
  -- Add cmp highlight groups for transparency
  "CmpItemAbbr",
  "CmpItemAbbrDeprecated",
  "CmpItemAbbrMatch",
  "CmpItemAbbrMatchFuzzy",
  "CmpItemMenu",
  "CmpItemKindText",
  "CmpItemKindVariable",
  "CmpItemKindMethod",
  "CmpItemKindFunction",
  "CmpItemKindConstructor",
  "CmpItemKindField",
  "CmpItemKindClass",
  "CmpItemKindInterface",
  "CmpItemKindModule",
  "CmpItemKindProperty",
  "CmpItemKindValue",
  "CmpItemKindEnum",
  "CmpItemKindKeyword",
  "CmpItemKindSnippet",
  "CmpItemKindFile",
  "CmpItemKindFolder",
  "CmpItemKindEvent",
  "CmpItemKindOperator",
  "CmpItemKindTypeParameter",
}

for _, group in ipairs(hl_groups_transparent) do
  vim.api.nvim_set_hl(0, group, { bg = "NONE" })
end

-- Set a border for the floating terminal and disable transparency for it
vim.api.nvim_set_hl(0, "NormalFloat", { bg = "#1D1E2E" }) -- Adjust bg to your preferred color for terminal
vim.api.nvim_set_hl(0, "FloatBorder", { bg = "#1D1E2E", fg = "#C678DD" }) -- Adjust bg and fg colors to your liking
